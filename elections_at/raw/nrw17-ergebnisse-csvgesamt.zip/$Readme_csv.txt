

Satzaufbau



Spalte	Inhalt				Format

1	Gebietskennung*			Schl�ssel
2	Gebietsname			alpha
3	Wahlberechtigte			numerisch
4	Anzahl der abgegebene Stimmen	numerisch
5	Anzahl der ung�ltige Stimmen	numerisch
6	Anzahl der g�ltige Stimmen	numerisch
7-n	Stimmen je Partei oder Kandidat	numerisch

Erkl�rungen:
Spalte 1 - Gebietskennung (im Datensatz)
Die Beschreibung der Gebietskennungs-Schl�ssel ist aus der (f�r jede Wahl aktualisierten) BM.I Tabelle zu entnehmen.

Spalte 7-n - Stimmen je Partei oder Kandidat
Parteienwahlen (Nationalratswahlen, EU-Wahlen):
Im Header sind die kandidierenden Parteien lt. Bundeswahlvorschlag mit ihrer Kurzbezeichnung angef�hrt.
Im Datensatz sind die g�ltigen Stimmen je Partei (spaltensortiert) angef�hrt.
ACHTUNG: Die Parteienreihung ist bei allen Datens�tzen 
(lt. Header) ident!
Eine leere Spalte bedeutet, dass diese Parte in diesem Gebiet NICHT kandidiert hat!
Kandidatenwahlen (Bundespr�sidentenwahl):
Im Header sind die Kandidaten lt. Bundeswahlvorschlag namentlich angef�hrt.
Im Datensatz sind die g�ltigen Stimmen je Kandidat (spaltensortiert) angef�hrt.



Beispiel:

;Gebietsname;Wahlberechtigte;Abgegebene;Ung�ltige;G�ltige;SP�;�VP;FP�;BZ�;GR�NE;FRANK;NEOS;KP�;PIRAT;CP�;WANDL;M;EUAUS;SLP;

G00000;�sterrreich;6384308;4782410;89503;4692907;1258605;1125876;962313;165746;582657;268679;232946;48175;36265;6647;3051;490;510;947;

G10000;Burgenland;232505;192486;4102;188384;70222;50426;32705;3689;12718;11050;5327;930;871;446;;;;;

G10099;Wahlkarten - Burgenland;0;17;17;0;0;0;0;0;0;0;0;0;0;0;;;;;

